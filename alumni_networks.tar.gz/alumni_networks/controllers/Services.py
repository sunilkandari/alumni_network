# -*- coding: utf-8 -*-
# try something like

"""
This is class is responsible for creating object based on the assess rights of the user.
"""
class AlumniService(Object):
    
    @staticmethod
    def factory(_type,token):
        user_type = db(db.tokens.token == token).select(db.tokens.generator_type)
        if _type=="Events":
            return Events()
        elif _type=="Jobs":
            return Jobs(user_type)

        elif _type=="Assist":
            return Assist(user_type)

        elif _type=="Gallery":
            return Gallery(user_type)

        elif _type=="Manage":
            if gen_type=="ADMIN":
                return Manage()
            else:
                return None
        elif _type=="Search":
            return Search()

        elif _type=="NewsRoom":
            if gen_type=="ADMIN":
                return Newsroom()
            else:
                return None
        else:
            return None


class Events(AlumniService):
    def __init__(self):
        pass
    def addNewEvent(form):
        db.eventlist.insert(event_name = form.vars.event_name, description = form.vars.description, event_date = form.vars.event_date, venue = form.vars.venue)
        return True

    def getAll():
        events=db(db.eventlist).select()
        return events

    def applyForEvent(event_id,app_name,token):
        
        gen_type = db(db.tokens.token == token).select(db.tokens.generator_type)
        if gen_type == None or gen_type=="STUDENT":
            return False
        else:
            post = db.eventlist(event_id)
            db.applied_event.insert(event_name = post.event_name, description =post.description, applier_email=email_id, applier_name=app_name)
            return True


class Jobs(AlumniService):
    def __init__(self):
        pass
    def postNewJob(form):
        db.job.insert(Company_Name = form.vars.Company_Name, Description = form.vars.Description, LastDate = form.vars.LastDate, em=email_id)
        return True

    def applyForJob(job_id,app_name):
        post = db.job(job_id)
        db.applied_job.insert(rec_email = post.em, applier_name = app_name, applier_email = email_id, applied_com=post.Company_Name, description=post.Description)
        return True

    def getAll():
        jobs=db(db.job).select()
        return jobs

    def getAllJobsPostedBy(email):
        jobs=db(db.job.em == email_id).select()
        return jobs

    def getAllJobAppliedBy(email):
        jobs=db(db.applied_job.applier_email == email_id).select()
        return jobs


class Assist(AlumniService):
    def __init__(self):
        pass
    def getAll():
        all_requests=db(db.e_request).select()
        return all_requests
    
    def makeERequest(form):
        db.e_request.insert(request_type=form.vars.request_type, description=form.vars.description,request_date=\
                            form.vars.request_date, applier_email=email_id,applier_name=form.vars.applier_name)
        return True

    def getAllRequestsStatus():
        status_list=db(db.e_request.applier_email == email_id).select()
        return status_list

class Gallery(AlumniService):
    def __init__(self):
        pass
    def addPhotos(form):
        db.photos.insert(description = form.vars.description, request_date = form.vars.request_date,   image = form.vars.photo)
        return True
    def getAll():
        photos=db(db.photos).select()
        return photos


class Search(AlumniService):
    def __init__(self):
        pass
    
    def getAll():
        all_mems=db(db.auth_user).select()
        return all_mems
    
    def getAllAdmins():
        all_admins=db(db.auth_user.registration_type == "ADMIN").select()
        return all_admins

    def getAllAlumnis():
        all_alumnis=db(db.auth_user.registration_type == "ALUMNI").select()
        return all_alumnis

    def getAllStudents():
        all_students=db(db.auth_user.registration_type == "STUDENT").select()
        return all_students

    def searchBy(search_type,value):
        if search_type == "job":
            search_result=db(db.auth_user.job.contains(value.lower())).select()
        elif search_type == "location":
            search_result=db(db.auth_user.current_location.contains(value)).select()
        elif search_type == "name":
            search_result=db(db.auth_user.first_name.contains(value)|db.auth_user.last_name.contains(value)).select()
        elif search_type == "bachof":
            search_result=db(db.auth_user.year_of_joining.year.contains(value)).select()
        elif search_type == "program":
            search_result=db(db.auth_user.program.contains(value)).select()
        else:
            search_result=None
        return search_result

class Newsroom(AlumniService):
    def __init__(self):
        pass
    def getAll():
        all_news=db(db.newsroom).select(orderby=db.newsroom.title.upper())
        return all_news

    def getNewsById(news_id):
        news=db.newsroom(news_id)
        return news

    def getCommentForNews(news):
        comments=db(db.news_comment.newsroom==news.id).select()
        return comments

    def getCommentByNewsId(news_id):
        comments=db(db.news_comment.newsroom==news_id).select()
        return comments

    
class Manage(AlumniService):
    def __init__(self):
        pass
    def getAll():
        pass
    def getAdminAccessTo(access_type):
        if access_type == "Job":
            job_access=SQLFORM.grid(db.job)
            return job_access

        elif access_type == "Events":
            event_access=SQLFORM.grid(db.eventlist)
            return job_access

        elif access_type == "Registrations":
            reg_access=SQLFORM.grid(db.job)
            return reg_access

        elif access_type == "News":
            news_access=SQLFORM.grid(db.newsroom)
            return news_access

        elif access_type == "Assist":
            assist_access=SQLFORM.grid(db.e_request)
            return assist_access
        else:
            return None
