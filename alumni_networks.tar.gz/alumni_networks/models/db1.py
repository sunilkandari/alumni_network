# -*- coding: utf-8 -*-


db.define_table('newsroom',
               Field('title',requires=IS_NOT_EMPTY()),
               Field('body','text',requires=IS_NOT_EMPTY()),
               auth.signature
               )
db.define_table('news_comment',
                Field('newsroom','reference newsroom'),
                Field('post_comment',requires=IS_NOT_EMPTY()),
                auth.signature)

db.define_table('job',
                Field('Company_Name', 'string',requires=IS_NOT_EMPTY()),
                Field('Post', 'string',requires=IS_NOT_EMPTY()),
                Field('Description', 'text',requires=IS_NOT_EMPTY()),
                Field('LastDate', 'datetime'),
                Field('em',requires = IS_EMAIL(error_message='invalid email!')))

db.define_table('applied_job',
                Field('rec_email','string',IS_EMAIL(error_message='invalid email!')),
                Field('applier_name','string',requires=IS_NOT_EMPTY()),
                Field('applier_email','string',IS_EMAIL(error_message='invalid email!')),
                Field('applied_com','string',requires=IS_NOT_EMPTY()),
                Field('description','text',requires=IS_NOT_EMPTY()))

db.define_table('eventlist',
                Field('event_name', 'string',requires=IS_NOT_EMPTY()),
                Field('description', 'text',requires=IS_NOT_EMPTY()),
                Field('event_date', 'date'),
                Field('venue','string',requires=IS_NOT_EMPTY()))

db.define_table('applied_event',
                Field('event_name','string',requires=IS_NOT_EMPTY()),
                Field('description','text',requires=IS_NOT_EMPTY()),
                Field('applier_email','string',IS_EMAIL(error_message='invalid email!')),
                Field('applier_name','string',requires=IS_NOT_EMPTY()))

db.define_table('e_request',
                Field('request_type'),
                Field('description','text',requires=IS_NOT_EMPTY()),
                Field('request_date','datetime',requires=IS_NOT_EMPTY()),
                Field('applier_email','string',IS_EMAIL(error_message='invalid email!')),
                Field('applier_name','string',requires=IS_NOT_EMPTY()),
                Field('status','string',requires=IS_IN_SET(('Pending','Approved')),default="Pending"))


db.define_table('photos',
                Field('description','string',requires=IS_NOT_EMPTY()),
                Field('request_date','datetime',requires=IS_NOT_EMPTY()),
                Field('image', 'upload',requires=IS_NOT_EMPTY(),uploadfolder=path.join(request.folder,'static','images1','dp'), autodelete=True))
db.define_table('tokens',
                Field('generator_email',requires = IS_EMAIL(error_message='invalid email!')),
                Field('description'),
                Field('generator_type','string', requires=IS_IN_SET(('STUDENT','ADMIN','ALUMNI')),default='STUDENT'),
                Field('token','string',requires=IS_NOT_EMPTY()))
